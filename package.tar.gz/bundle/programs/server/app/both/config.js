(function(){/*
MessageFormat default language setting.
English is primary project language.
*/
mfPkg.init('en');

}).call(this);

//# sourceMappingURL=config.js.map
