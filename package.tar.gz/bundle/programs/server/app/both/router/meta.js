(function(){Meteor.startup(function() {
  if(Meteor.isClient) {
    Meta.config({
      options: {
        // Meteor.settings[Meteor.settings.environment].public.meta.title
        suffix: 'Crowducate'
      }
    });
  }
});

}).call(this);

//# sourceMappingURL=meta.js.map
