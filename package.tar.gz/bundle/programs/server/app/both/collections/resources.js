(function(){Resources = new Mongo.Collection('resources');

}).call(this);

//# sourceMappingURL=resources.js.map
