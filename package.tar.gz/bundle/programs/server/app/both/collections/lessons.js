(function(){Lessons = new Mongo.Collection('lessons');

}).call(this);

//# sourceMappingURL=lessons.js.map
