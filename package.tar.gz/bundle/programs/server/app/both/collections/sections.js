(function(){Sections = new Mongo.Collection('sections');

}).call(this);

//# sourceMappingURL=sections.js.map
