(function(){Schema = {};

}).call(this);

//# sourceMappingURL=_schemas.js.map
