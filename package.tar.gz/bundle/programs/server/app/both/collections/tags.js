(function(){Tags = new Mongo.Collection('tags');

}).call(this);

//# sourceMappingURL=tags.js.map
