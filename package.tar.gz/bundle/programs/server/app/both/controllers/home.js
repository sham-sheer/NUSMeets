(function(){HomeController = AppController.extend({
  data: {

  }
});

}).call(this);

//# sourceMappingURL=home.js.map
