(function(){ProfileSettingsController = AppController.extend({
  data: {

  },
  waitOn: function() {
      return this.subscribe('userData');
  },
  onBeforeAction: function (pause) {
      AccountsTemplates.ensureSignedIn.call(this, pause);
  }
});

}).call(this);

//# sourceMappingURL=profileSettings.js.map
