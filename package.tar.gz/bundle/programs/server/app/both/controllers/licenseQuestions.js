(function(){LicenseQuestionsController = AppController.extend({
  data: {

  }
});

}).call(this);

//# sourceMappingURL=licenseQuestions.js.map
