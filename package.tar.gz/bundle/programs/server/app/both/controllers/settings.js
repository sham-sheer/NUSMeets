(function(){SettingsController = AppController.extend({
  data: {

  }
});

}).call(this);

//# sourceMappingURL=settings.js.map
