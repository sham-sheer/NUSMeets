(function(){TesteventInfoController = AppController.extend({
  data: {

  }
});

}).call(this);

//# sourceMappingURL=testcourseInfo.js.map
