(function(){SimpleSchema.messages({
    "passwordMismatch": "Passwords do not match"
});
}).call(this);

//# sourceMappingURL=common.js.map
