(function(){Meteor.methods({
  'getLikesCount' : function () {
    return Events.find().count();
  }
});

}).call(this);

//# sourceMappingURL=likes.js.map
