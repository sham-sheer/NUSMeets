(function(){Meteor.publish('singleSection', function (sectionID) {
    return Sections.find({"_id": sectionID});
});

}).call(this);

//# sourceMappingURL=sections.js.map
