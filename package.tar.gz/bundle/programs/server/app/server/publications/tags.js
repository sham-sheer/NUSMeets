(function(){Meteor.publish('tags', function () {
    return Tags.find();
});

}).call(this);

//# sourceMappingURL=tags.js.map
