(function(){// Settings related to the browser-policy security package

// eval() is used by MessageFormat v1, so is necessary
BrowserPolicy.content.allowEval();

}).call(this);

//# sourceMappingURL=browser-policy.js.map
