(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var EditableText = Package['babrahams:editable-text'].EditableText;
var sanitizeHtml = Package['djedi:sanitize-html'].sanitizeHtml;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['babrahams:editable-text-wysiwyg-bootstrap-3'] = {};

})();

//# sourceMappingURL=babrahams_editable-text-wysiwyg-bootstrap-3.js.map
