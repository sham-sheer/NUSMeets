(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Meta;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/yasinuslu_blaze-meta/packages/yasinuslu_blaze-meta.js    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['yasinuslu:blaze-meta'] = {
  Meta: Meta
};

})();

//# sourceMappingURL=yasinuslu_blaze-meta.js.map
